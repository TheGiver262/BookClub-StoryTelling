# Trạng thái và quyết định hiện hành YSBK

Cập nhật bàn giao: 21/10/2026. Đây là trang điều phối tài liệu, không thay hợp đồng API hoặc tự phê duyệt tính năng. [Session handoff](SESSION-HANDOFF.md) chứa tóm tắt hội thoại và lời mở đầu chat tiếp theo.

## Thứ tự áp dụng

1. Quyết định trực tiếp mới nhất của chủ sản phẩm; đề xuất chưa được trả lời không phải quyết định.
2. Thiết kế nghiệp vụ hiện hành và tài liệu chuyên đề bên dưới.
3. Mã nguồn hiện có là bằng chứng implementation, không tự thay yêu cầu sản phẩm.
4. Kế hoạch/prompt/concept dùng hướng dẫn; review và log cũ chỉ chứng minh lần chạy được ghi. Nguồn HTML thô Stitch có thể sinh sai chính sách.

## Các chuyên đề hiện hành

| Chuyên đề | Tài liệu chính | Trạng thái |
|---|---|---|
| Đặt sách khách, hạn mức, hết hạn, bảo mật | [Thiết kế](technical/public-reservation-design.md), [bàn giao](technical/public-reservation-handoff.md) | Có implementation local; chưa beta cloud |
| Cổng chung, xuất bản, CTV | [Public portal/publishing](technical/public-portal-publishing.md) | Đã có source và bằng chứng local theo tài liệu chuyên đề |
| Landing cuốn sách | [Landing local](technical/book-landing-local.md) | Tích hợp local; bìa phụ/ảnh/nội dung theo phản hồi mới |
| UI mềm PC/mobile | [Đặc tả](mockups/stitch-ui-2026-10-21/HANDOFF.md), [kế hoạch](superpowers/plans/2026-10-21-ysbk-soft-ui.md) | 14 mẫu; workspace đã có thay đổi UI sau concept, chưa review đầy đủ trong lượt bàn giao |
| Đặt/hủy, tài khoản tùy chọn | [Nghiên cứu 21/10](technical/public-reservation-ux-research-2026-10-21.md) | Đang thảo luận, chưa duyệt code |
| Runtime local | [Hướng dẫn](technical/local-development.md) | 4321; lần bàn giao readiness 200 DB/Auth connected |
| Beta | [Deploy guide](technical/beta-deployment-guide.md), [bằng chứng](technical/beta-verification.md) | Supabase + Cloudflare Free đã chọn; local trước, chưa deploy |

## Điều đã chốt và chưa thay đổi

- Một quyển/đơn giữ chỗ, không đăng nhập/OTP, CAPTCHA, nhận đúng ca; hết hạn cuối ca đã chọn.
- Ba đơn tạo thành công/IP/24 giờ trượt; hủy/hết hạn/trả không hoàn lượt IP. Ba suất giữ/mượn chưa trả/SĐT; trả một mở một suất.
- Chỉ người có quyền đơn mới xem/hủy; không cấp quyền từ SĐT/mã đơn công khai. Chỉ hủy khi chờ nhận, không hủy để thay thủ tục trả sách đã giao.
- Cổng `/sach/` đủ sáu mục, 50 sách/trang; `/cong-dong` giữ liên kết cũ qua redirect; session nội bộ không tự đẩy người đang xem tủ sách đi.
- Chỉ ADMIN xuất bản sách/ảnh/lịch/nghỉ/sự kiện/tuyển. CTV một tháng lịch, quyền MEMBER, quản lý đánh giá và công nhận; xóa CTV mềm/giữ lịch sử; thành viên rời chuyển cựu.
- Tên đầy đủ và slogan có dấu phẩy; màu đã chốt; phong cách UI mềm/vintage, landing sách giữ thiết kế đã duyệt.
- Bản báo cáo khảo sát và tài khoản khách cho review trước đây không tự cấp chức năng tài khoản bạn đọc quản lý giữ chỗ. Tính năng này đang mở lại để thảo luận.

## Đề xuất chưa được duyệt

Trang “Sách của tôi”, nhớ đơn khách theo phiên thiết bị, tài khoản bạn đọc tùy chọn, email/liên kết khôi phục, đổi sách nguyên tử và thay chính sách IP. Chưa sửa code/guard/schema theo các ý này. Rủi ro Wi-Fi dùng chung IP cần đo, không đồng nhất IP với một người; SĐT tự khai chưa phải danh tính được xác minh.

## Cách đọc các tài liệu lịch sử

Tài liệu khám phá 18/10, review theo chặng, prompt Antigravity cũ, ảnh QA và các snapshot verification vẫn giữ để truy vết. Chúng không chứng minh trạng thái hiện tại chỉ vì có chữ PASS, “chưa có DB” hoặc “chưa tích hợp”. Tài liệu đang dùng được bổ sung mục cập nhật; các điều không bị thay thế như cọc/phạt/quỹ tiếp tục có hiệu lực theo quyết định đã chốt.

## Phạm vi đợt đồng bộ tài liệu

Đồng bộ README, chín tài liệu sản phẩm, các tài liệu kỹ thuật/vận hành đang dùng, kế hoạch/prompt UI và index prompt. Không sửa lại kết quả review lịch sử, migration SQL, OpenAPI, source code, ảnh gốc hoặc bản xuất thô Stitch để giả vờ tính năng mới đã được duyệt. Gói ZIP UI được cập nhật các tài liệu bàn giao liên quan; dùng file trong workspace làm nguồn mới nhất.
