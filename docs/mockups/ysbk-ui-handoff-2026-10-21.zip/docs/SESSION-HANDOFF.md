# YSBK — Session handoff ngày 21/10/2026

## 1. Bắt đầu chat mới từ đây

Mục tiêu tiếp theo là **thảo luận lại trải nghiệm đặt, tìm lại, đổi và hủy sách**. Người dùng yêu cầu bàn giao rồi chuyển chat; chưa duyệt triển khai tài khoản bạn đọc, đổi sách hoặc thay hạn mức IP. Không tự bắt đầu code từ các đề xuất nghiên cứu.

Đọc tiếp theo thứ tự:

1. [Quyết định hiện hành](CURRENT-STATE.md): phân biệt đã chốt, đã có trong source và đề xuất.
2. [Nghiên cứu UX đặt sách](technical/public-reservation-ux-research-2026-10-21.md): Koha, LibCal, Acuity; nguồn chính thức và giới hạn suy luận.
3. [Thiết kế đặt sách](technical/public-reservation-design.md), [bàn giao triển khai](technical/public-reservation-handoff.md).
4. [Cổng công khai, quản lý nội dung, CTV](technical/public-portal-publishing.md).
5. [Bộ thiết kế Stitch](mockups/stitch-ui-2026-10-21/HANDOFF.md), [kế hoạch UI](superpowers/plans/2026-10-21-ysbk-soft-ui.md).

## 2. Repo, nhánh và phạm vi công việc

- Workspace: `F:\Codex Project\YSBK`.
- Kiểm tra ngay khi viết handoff: nhánh `main`, HEAD `b9d568b4c4ba9c8d390fef3bb80f7abce52b8abb`; chỉ một worktree tại workspace trên.
- Có nhiều thay đổi tracked và untracked của các đợt trước/Antigravity. Không reset, clean, stash, ghi đè hoặc gom commit toàn bộ.
- Lượt bàn giao này chỉ cập nhật tài liệu và gói tài liệu; không sửa source, schema, cấu hình hoặc dữ liệu. Không commit, push hay deploy.
- HEAD và working tree không đồng nghĩa với trạng thái GitHub. Chưa fetch/đối chiếu remote trong lượt này.
- Không dùng subagent nếu người dùng chưa cho phép trực tiếp trong yêu cầu hiện tại. Giao tiếp tiếng Việt; Caveman full/Ponytail; dùng RTK khi giữ đủ bằng chứng. Không ghi mật khẩu, cookie, token, chuỗi kết nối thật vào handoff.

## 3. Tóm tắt tiến trình hội thoại

1. Tách phần công khai và nội bộ: người ngoài xem landing, hoạt động, sách và đặt trước; thành viên đăng nhập bằng tài khoản được cấp, có session để vào nội bộ trực tiếp.
2. Chốt đặt giữ chỗ không đăng nhập, mỗi đơn một quyển, CAPTCHA/Turnstile, hạn nhận cuối buổi trực, hạn mức IP và SĐT riêng biệt. Review/sửa implementation đã có qua nhiều vòng; không dùng số liệu cũ để khẳng định mọi chức năng hiện tại đã nghiệm thu.
3. Chọn Supabase + Cloudflare gói miễn phí cho beta. Sau đó ưu tiên hoàn chỉnh local bằng Docker trước, beta cloud để sau. Quy mô dự kiến vài nghìn sách, khoảng 30 người nội bộ và 100 bạn đọc; tải mượn/trả chủ yếu thứ Ba/thứ Năm, cần đo thực tế.
4. Landing được phát triển từ mockup thành cuốn sách có bìa cứng, bìa phụ và 10 chương; ảnh thật, nội dung CLB, hiệu ứng cuộn/lật có điều khiển. Đã tích hợp local.
5. Gộp cổng công khai thành `/sach/` đủ sáu tab; bổ sung tóm tắt sách, upload/quản lý nội dung và vòng đời CTV một tháng, chỉ quản lý công nhận/xóa CTV. Thành viên rời CLB chuyển cựu.
6. Dùng Google Stitch tạo concept vintage mềm cho PC/mobile, giữ bảng màu. Đã xuất 14 mẫu, đặc tả, prompt Antigravity, kế hoạch và ZIP. Workspace hiện còn có UI implementation và ảnh QA xuất hiện sau mốc xuất concept; chưa review toàn bộ diff mới trong lượt này.
7. Người dùng hỏi khách hủy/đặt nhầm và tài khoản bạn đọc. Đối chiếu source thấy hủy bằng token riêng đã có, chỉ khi `HELD`; chưa tìm thấy luồng đổi sách nguyên tử trong phần đã đọc.
8. Theo yêu cầu tra cứu mạng, đã nghiên cứu tài liệu chính thức: Koha quản lý sách qua tài khoản; LibCal dùng liên kết hủy trong email; Acuity cho đặt khách kèm tài khoản tùy chọn. Đề xuất trang “Sách của tôi”, tài khoản tùy chọn, đổi sách và xem lại IP; **chưa có quyết định triển khai**.

## 4. Các quyết định sản phẩm đang có hiệu lực

### Công khai, giữ chỗ và hạn mức

- Khách đặt không cần đăng nhập; chưa OTP; CAPTCHA/Turnstile kiểm tra server.
- Mỗi đơn đúng một bản sách vật lý, gắn một buổi trực. Đây là giữ chỗ, chưa phải giao sách.
- Giữ tới hết buổi trực đã chọn; không đến thì hết hạn, mở lại khả dụng. Nhận tại bàn sau kiểm tra họ tên/SĐT và xác nhận nghiệp vụ.
- IP tối đa ba đơn tạo thành công trong 24 giờ trượt, cộng mọi SĐT cùng IP. Hủy/hết hạn/trả không hoàn lượt IP trong cửa sổ đó.
- SĐT tối đa ba suất gồm giữ còn hiệu lực và đã nhận chưa trả, cộng các IP/kênh. Trả một quyển mở một suất SĐT nhưng vẫn phải còn lượt IP để tạo mới.
- Tự xem/hủy đơn bằng quyền từ liên kết/token bí mật; không dùng SĐT hoặc mã đơn công khai để cấp quyền. Không lộ token trong log/query/analytics.
- Danh mục 50 đầu sách/trang, lọc/tìm kiếm, hiện cả sách hết bản nhưng không cho giữ. Refresh hiện có 30 giây thứ Ba/Năm, 60 giây ngày khác, khi quay lại và sau thay đổi; server quyết định tồn khi đặt.
- Bản đã giữ không thể giao: cảnh báo nội bộ kèm thông tin cần liên hệ, thành viên gọi và xử lý thủ công. Chưa tự gửi email/SMS hoặc tự hủy vì sự cố.
- Không đưa thuật ngữ IP/hạn mức kỹ thuật ra mô tả công khai. Vẫn cần thông báo lỗi dễ hiểu và đường liên hệ; backend giữ guard.

### Nội dung và nhân sự

- `/sach/` là một cổng chung: Tra cứu sách, Đặt giữ chỗ, Tra cứu đơn, Lịch trực & sự kiện, Góc review, Tuyển thành viên.
- Chỉ `ADMIN` quản lý xuất bản sách/ảnh/tóm tắt, lịch trực/nghỉ, sự kiện công khai và thông tin tuyển. Không mở quyền upload nội dung cho toàn bộ thành viên/CTV.
- CTV thử thách một tháng lịch, quyền nghiệp vụ như `MEMBER` với cờ nhân sự riêng. Không tự công nhận sau hết tháng: quản lý phải đánh giá đạt.
- Chỉ quản lý xóa CTV, xóa mềm/thu hồi phiên/giữ lịch sử. Thành viên chính thức rời CLB chuyển `ALUMNI`; quyền cựu chỉ hoạt động an toàn, không PII/tài chính/xuất dữ liệu.
- Quy tắc tài chính và chứng từ đã chốt tiếp tục áp dụng; đặt trước một quyển/đơn không thay giới hạn tối đa hai quyển/phiếu mượn tại quầy.

### Nhận diện và giao diện

- Tên: **Câu lạc bộ Yêu Sách Bách Khoa Hà Nội**. Slogan: **Mở sách, đọc tương lai**. Thành lập **16/09/2013**.
- Bìa cứng có độ dày/nhô; bìa phụ trái trắng, phải cùng thiết kế nhưng nhạt trên giấy; bỏ dòng địa danh/ngày dưới cả hai bìa, tách hai logo HUST/Hội Sinh viên.
- Nội dung: giới thiệu → con người → hoạt động tổng quan → từng hoạt động → slogan/tranh kết. Ảnh người dùng đã gửi; bỏ tặng giáo trình, thay giao lưu CLB bằng Ngày Sách Việt Nam. Không lấy ảnh bất kỳ gán sai sự kiện.
- Chốt màu xanh rêu, đất nung, giấy kem; logo SVG gốc nét/transparent. Stitch “Thư viện ký ức — góc bo mềm”: control 14px, card 22px, modal 24px, bóng nhẹ, không quá vuông.
- Newsreader cho heading/Be Vietnam Pro cho UI; Dancing Script trên bìa/kết giữ dấu Việt. Typography thực tế trong source cần đối chiếu khi review implementation.
- Áp dụng nhận diện cả công khai và nội bộ, PC/mobile. Không thay landing cuốn sách đã duyệt bằng landing mẫu Stitch.

## 5. Trạng thái hiện vật và kiểm chứng

| Hạng mục | Bằng chứng hiện có | Giới hạn |
|---|---|---|
| Local runtime | Lượt handoff: `/health/ready` HTTP 200, database/Auth provider connected; landing 4321 HTTP 200 | Không phải toàn bộ UAT nghiệp vụ hoặc kiểm tra source đang chạy khớp diff |
| Concept | Preview `http://127.0.0.1:4323/` HTTP 200; 14 mẫu và manifest | HTML mẫu không chứng minh chức năng thật |
| Giữ chỗ/landing/publishing/CTV | Tài liệu đợt trước ghi 353 unit, check 0/0/0, 7 test PG nội dung/CTV và 12 test hồi quy giữ chỗ; các log được dẫn trong tài liệu | Số liệu theo từng lần chạy, chưa chạy lại suite trong lượt handoff |
| UI sau bộ concept | Có `src/styles/ui.css`, được import từ `global.css`; thay đổi theme/component và thư mục `docs/mockups/qa-evidence-2026-10-21/` | Chỉ xác nhận hiện vật/source; chưa đọc hết diff, chưa xác nhận mọi ảnh gắn đúng SHA hoặc đủ nghiệm thu |
| Browser | Trước đây có bằng chứng local; lần công cụ gần nhất bị Work settings chặn, mở panel trả queued | Phải thử lại ở chat mới, không mặc định quyền vẫn bị chặn hoặc đã mở |
| Cloud beta | Có cấu hình và hướng dẫn | Chưa deploy/nghiệm thu provider thật, Turnstile thật, tải đồng thời hay thiết bị thật |

Không nâng các kết quả unit/source thành chứng minh DB/cloud/concurrency. Báo cáo cũ 18–20/10 và progress theo chặng được giữ làm lịch sử, không là trạng thái hiện tại của mọi gate.

## 6. Vấn đề mở cho chat sau

**Nên bắt đầu bằng trải nghiệm tìm lại đơn, chưa bằng chọn nhà cung cấp tài khoản.**

1. “Sách của tôi” dành cho khách trên cùng trình duyệt có đủ hay cần tài khoản bạn đọc tùy chọn ngay beta?
2. Nếu vẫn không email/SMS/OTP, có chấp nhận hỗ trợ thủ công khi mất liên kết/quên mật khẩu không? Không hứa đồng bộ hoặc khôi phục tự động khi chưa có kênh chứng minh quyền.
3. Có thêm “Đổi sách” khi chờ nhận không? Đề xuất giữ bản mới/nhả bản cũ nguyên tử, thất bại giữ đơn cũ, không reset thời hạn hoặc lượt IP, có audit/chống đổi liên tục.
4. Có xem lại ba đơn/IP/24 giờ vì nhiều bạn đọc dùng chung mạng không? Đây mới là đề xuất; chưa chọn ngưỡng mới hoặc sửa guard.
5. Nếu mở tài khoản, chốt cách gắn đơn khách vào tài khoản bằng bằng chứng hợp lệ; không nhận toàn bộ lịch sử chỉ dựa trên SĐT tự khai. Tách tuyệt đối khỏi tài khoản/quyền nội bộ.

## 7. Mẫu lời mở đầu chat mới

> Tiếp tục dự án YSBK tại `F:\Codex Project\YSBK`. Đọc `docs/SESSION-HANDOFF.md`, `docs/CURRENT-STATE.md` và tài liệu nghiên cứu UX đặt sách được dẫn. Trước mắt chỉ thảo luận/chốt lại cách khách đặt, tìm lại, đổi và hủy sách, cùng việc có tài khoản bạn đọc tùy chọn hay không. Các đề xuất ở cuối chat trước chưa được duyệt triển khai; giữ nguyên hạn mức đã chốt cho đến khi tôi quyết định. Giữ mọi thay đổi đang có trên main, không tự commit/push/deploy hoặc dùng subagent. Nếu cần bàn tới UI, kiểm tra implementation/ảnh QA đang có trước, không làm lại từ bộ concept cũ.
